<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header text-center">MENU</li>
      <li><a href="index.php"><i class="fas fa-fw fa-users"></i><span> &nbsp;Pelanggan</span></a></li>
      <li><a href="index.php?p=supplier"><i class="fas fa-user-tie"></i><span> &nbsp;&nbsp;&nbsp;Supplier</span></a></li>
      <li><a href="index.php?p=barang"><i class="fa fa-shopping-cart"></i><span> Barang</span></a></li>
      <li><a href="index.php?p=jenisbarang"><i class="fa fa-shopping-cart"></i><span> Jenis Barang</span></a></li>
      <li><a href="index.php?p=penjualan"><i class="fa fa-shopping-cart"></i><span> Penjualan</span></a></li>
      <li><a href="index.php?p=pembelian"><i class="fa fa-shopping-cart"></i><span> Pembelian</span></a></li>
      <li><a href="index.php?p=user"><i class="fa fa-user"></i><span> User</span></a></li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
