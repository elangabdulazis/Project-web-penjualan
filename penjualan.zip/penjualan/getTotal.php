<?php
  include('view/koneksi.php');
  $nofaktur = isset($_GET['nofaktur'])?$_GET['nofaktur']:'';
  if($_GET['j']=='pembelian'){
    $data = mysqli_query($koneksi,"select sum(sub_total) as 'sub_total' from detail_pembelian where faktur = '$nofaktur'");
  }elseif($_GET['j']=='penjualan'){
    $data = mysqli_query($koneksi,"select sum(sub_total) as 'sub_total' from detail_penjualan where faktur = '$nofaktur'");
  }
  $row=mysqli_fetch_array($data);
  echo $row['sub_total'];
?>
