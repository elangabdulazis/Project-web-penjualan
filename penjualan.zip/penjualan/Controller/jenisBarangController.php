<?php
include('../View/koneksi.php');
  if($_GET['aksi']=='tambah'){
    $jenis = isset($_POST['txtJenis'])?$_POST['txtJenis']:'';
    $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';  
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into jenis_barang values(0,'$jenis','$keterangan')");
      if($simpan){
        header('location:../index.php?p=jenisbarang');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $id = $_GET['id_jenis'];
    $jenis = isset($_POST['txtJenis'])?$_POST['txtJenis']:'';
    $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';  
    if(isset($_POST['btnSubmit'])){
      $edit = mysqli_query($koneksi,
      "update jenis_barang
      set nama_jenis = '$jenis',
      keterangan = '$keterangan'
      where id_jenis = $id");
      if($edit){
        header('location:../index.php?p=jenisbarang');
      };
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from jenis_barang where id_jenis='$_GET[id_jenis]'");
    if($hapus){
        header('location:../index.php?p=jenisbarang');
    }
  }
?>
