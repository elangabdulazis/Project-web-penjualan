<?php
include('../View/koneksi.php');
  if($_GET['aksi']=='tambah'){
    $nama = isset($_POST['txtNamaPel'])?$_POST['txtNamaPel']:'';
    $telp = isset($_POST['txtTelp'])?$_POST['txtTelp']:'';
    $email = isset($_POST['txtEmail'])?$_POST['txtEmail']:'';
    $alamat = isset($_POST['txtAlmt'])?$_POST['txtAlmt']:'';
    $kel = isset($_POST['txtKel'])?$_POST['txtKel']:'';
    $kec = isset($_POST['txtKec'])?$_POST['txtKec']:'';
    $kota = isset($_POST['txtKota'])?$_POST['txtKota']:'';
    $prov = isset($_POST['txtProv'])?$_POST['txtProv']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into pelanggan values(0,'$nama','$telp','$email','$alamat','$kel','$kec','$kota','$prov')");
      if($simpan){
        header('location:../index.php?p=pelanggan');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $id = $_GET['id_pelanggan'];
    $nama = isset($_POST['txtNamaPel'])?$_POST['txtNamaPel']:'';
    $telp = isset($_POST['txtTelp'])?$_POST['txtTelp']:'';
    $email = isset($_POST['txtEmail'])?$_POST['txtEmail']:'';
    $alamat = isset($_POST['txtAlmt'])?$_POST['txtAlmt']:'';
    $kel = isset($_POST['txtKel'])?$_POST['txtKel']:'';
    $kec = isset($_POST['txtKec'])?$_POST['txtKec']:'';
    $kota = isset($_POST['txtKota'])?$_POST['txtKota']:'';
    $prov = isset($_POST['txtProv'])?$_POST['txtProv']:'';
    if(isset($_POST['btnSubmit'])){
      $edit = mysqli_query($koneksi,
      "update pelanggan
      set nama_pelanggan = '$nama',
      telp = '$telp',
      email = '$email',
      alamat = '$alamat',
      kelurahan = '$kel',
      kecamatan = '$kec',
      kota = '$kota',
      provinsi = '$prov' where id_pelanggan = $id");
      if($edit){
        header('location:../index.php?p=pelanggan');
      };
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from pelanggan where id_pelanggan='$_GET[id_pelanggan]'");
    if($hapus){
        header('location:../index.php?p=pelanggan');
    }
  }
?>
