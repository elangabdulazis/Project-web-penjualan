<?php
include('../View/koneksi.php');
  if($_GET['aksi']=='tambah'){
    $nama = isset($_POST['txtNamaBar'])?$_POST['txtNamaBar']:'';
    $jenis = isset($_POST['cmbJenis'])?$_POST['cmbJenis']:'';
    $satuan = isset($_POST['txtSatuan'])?$_POST['txtSatuan']:'';
    $hargabeli = isset($_POST['txtHargaBeli'])?$_POST['txtHargaBeli']:'';
    $hargajual = isset($_POST['txtHargaJual'])?$_POST['txtHargaJual']:'';
    $stok = isset($_POST['txtStok'])?$_POST['txtStok']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into barang values(0,'$nama','$jenis','$satuan',$hargabeli,$hargajual,$stok)");
      if($simpan){
        header('location:../index.php?p=barang');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $id = $_GET['id_barang'];
    $nama = isset($_POST['txtNamaBar'])?$_POST['txtNamaBar']:'';
    $jenis = isset($_POST['cmbJenis'])?$_POST['cmbJenis']:'';
    $satuan = isset($_POST['txtSatuan'])?$_POST['txtSatuan']:'';
    $hargabeli = isset($_POST['txtHargaBeli'])?$_POST['txtHargaBeli']:'';
    $hargajual = isset($_POST['txtHargaJual'])?$_POST['txtHargaJual']:'';
    $stok = isset($_POST['txtStok'])?$_POST['txtStok']:'';
    if(isset($_POST['btnSubmit'])){
      $edit = mysqli_query($koneksi,
      "update barang
      set nama_barang = '$nama',
      id_jenis = '$jenis',
      satuan = '$satuan',
      harga_beli = $hargabeli,
      harga_jual = $hargajual
      where id_barang = $id");
      if($edit){
        header('location:../index.php?p=barang');
      };
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from barang where id_barang='$_GET[id_barang]'");
    if($hapus){
        header('location:../index.php?p=barang');
    }
  }
?>
