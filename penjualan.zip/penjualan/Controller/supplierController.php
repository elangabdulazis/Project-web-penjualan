<?php
include('../View/koneksi.php');
  if($_GET['aksi']=='tambah'){
    $nama = isset($_POST['txtNamaSup'])?$_POST['txtNamaSup']:'';
    $telp = isset($_POST['txtTelp'])?$_POST['txtTelp']:'';
    $email = isset($_POST['txtEmail'])?$_POST['txtEmail']:'';
    $alamat = isset($_POST['txtAlmt'])?$_POST['txtAlmt']:'';
    $kel = isset($_POST['txtKel'])?$_POST['txtKel']:'';
    $kec = isset($_POST['txtKec'])?$_POST['txtKec']:'';
    $kota = isset($_POST['txtKota'])?$_POST['txtKota']:'';
    $prov = isset($_POST['txtProv'])?$_POST['txtProv']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into supplier values(0,'$nama','$telp','$email','$alamat','$kel','$kec','$kota','$prov')");
      if($simpan){
        header('location:../index.php?p=supplier');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $id = $_GET['id_supplier'];
    $nama = isset($_POST['txtNamaSup'])?$_POST['txtNamaSup']:'';
    $telp = isset($_POST['txtTelp'])?$_POST['txtTelp']:'';
    $email = isset($_POST['txtEmail'])?$_POST['txtEmail']:'';
    $alamat = isset($_POST['txtAlmt'])?$_POST['txtAlmt']:'';
    $kel = isset($_POST['txtKel'])?$_POST['txtKel']:'';
    $kec = isset($_POST['txtKec'])?$_POST['txtKec']:'';
    $kota = isset($_POST['txtKota'])?$_POST['txtKota']:'';
    $prov = isset($_POST['txtProv'])?$_POST['txtProv']:'';
    if(isset($_POST['btnSubmit'])){
      $edit = mysqli_query($koneksi,
      "update supplier
      set nama_supplier = '$nama',
      telp = '$telp',
      email = '$email',
      alamat = '$alamat',
      kelurahan = '$kel',
      kecamatan = '$kec',
      kota = '$kota',
      provinsi = '$prov' where id_supplier = $id");
      if($edit){
        header('location:../index.php?p=supplier');
      };
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from supplier where id_supplier='$_GET[id_supplier]'");
    if($hapus){
        header('location:../index.php?p=supplier');
    }
  }
?>
