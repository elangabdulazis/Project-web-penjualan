<?php
include('../View/koneksi.php');
  if($_GET['aksi']=='tambahdetail'){
    $id_barang = isset($_POST['id_barang'])?$_POST['id_barang']:'';
    $jumlah = isset($_POST['jumlahbarang'])?$_POST['jumlahbarang']:'';
    $hargajual = isset($_POST['hargajual'])?$_POST['hargajual']:'';
    $subtotal = isset($_POST['subtotal'])?$_POST['subtotal']:'';
    $nomorfaktur = isset($_POST['noFakturDetail'])?$_POST['noFakturDetail']:'';
    $page = $_GET['page'];
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into detail_penjualan values(0,'$nomorfaktur',$id_barang,$jumlah,$hargajual,$subtotal)");
      if($simpan){
        if($page=="update"){
          header('location:../index.php?p=penjualan&page=update&faktur='.$nomorfaktur);
        }else{
          header('location:../index.php?p=penjualan&page=entri');
        }
      }
    }
  }
  if($_GET['aksi']=='tambah'){
    $nomorfaktur = isset($_POST['txtNoFaktur'])?$_POST['txtNoFaktur']:'';
    $idpelanggan = isset($_POST['namaPelanggan'])?$_POST['namaPelanggan']:'';
    $total = isset($_POST['txtTotal'])?$_POST['txtTotal']:'';
    session_start();
    $user = $_SESSION['user'];
    $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';
    if(isset($_POST['btnSubmit'])){
      $simpan = mysqli_query($koneksi,"insert into penjualan (faktur,id_pelanggan,total_bayar,username,keterangan) values('$nomorfaktur',$idpelanggan,$total,'$user','$keterangan')");
      if($simpan){
        header('location:../index.php?p=penjualan');
      }
    }
  }
  else if($_GET['aksi']=='ubah'){
    $faktur = $_GET['faktur'];
    $nomorfaktur = isset($_POST['txtNoFaktur'])?$_POST['txtNoFaktur']:'';
    $idpelanggan = isset($_POST['namaPelanggan'])?$_POST['namaPelanggan']:'';
    $total = isset($_POST['txtTotal'])?$_POST['txtTotal']:'';
    session_start();
    $user = $_SESSION['user'];
    $keterangan = isset($_POST['txtKeterangan'])?$_POST['txtKeterangan']:'';
    if(isset($_POST['btnSubmit'])){
      $update = mysqli_query($koneksi,"
        update penjualan
        set id_pelanggan = $idpelanggan,
        total_bayar = $total,
        username = '$user',
        keterangan = '$keterangan'
        where faktur = '$faktur'");
      if($update){
        header('location:../index.php?p=penjualan');
      }
    }
  }
  else if($_GET['aksi']=='hapus'){
    $hapus = mysqli_query($koneksi,"delete from penjualan where faktur='$_GET[faktur]'");
    $hapusdetail = mysqli_query($koneksi,"delete from detail_penjualan where faktur='$_GET[faktur]'");
    if($hapus&&$hapusdetail){
        header('location:../index.php?p=penjualan');
    }
  }
  else if($_GET['aksi']=='hapus_detail'){
    $hapus = mysqli_query($koneksi,"delete from detail_penjualan where id='$_GET[id]'");
    $page = $_GET['page'];
    if($hapus){
        if($page=="update"){
          header('location:../index.php?p=penjualan&page=update&faktur='.$_GET['faktur']);
        }else{
          header('location:../index.php?p=penjualan&page=entri');
        }
    }
  }
?>
