<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      List Pembelian
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="box box-primary">
      <div class="box-body ">
        <?php
                include('koneksi.php');
              ?>
            <?php
                $page=isset($_GET['page'])?$_GET['page']:'list';
                switch ($page) {
                case 'list':
            ?>
            <p><a href="?p=pembelian&page=entri" class="btn btn-primary"><i class="fasfa-save mr-2"></i>Tambah Pembelian</a><a href="?p=pembelian&page=entri" class="btn btn-success ml-3"><i class="fasfa-save mr-2"></i>Laporan</a></p>
            <table class="table table-bordered text-center mt-3" id="example1">
                <thead>
                  <tr class="bg-primary">
                      <th>No</th>
                      <th>No Faktur</th>
                      <th>Tgl pembelian</th>
                      <th>Supplier</th>
                      <th>Total</th>
                      <th>Username</th>
                      <th>Keterangan</th>
                      <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                    $data = mysqli_query($koneksi,"select * from pembelian,supplier
                      where pembelian.id_supplier = supplier.id_supplier
                    ");
                    $i =1;
                    while ($row=mysqli_fetch_array($data)) {
                 ?>
                 <tr>
                        <td><?php echo $i?></td>
                        <td><?php echo $row['faktur']?></td>
                        <td><?php echo $row['tgl_pembelian']?></td>
                        <td><?php echo $row['nama_supplier']?></td>
                        <td><?php echo $row['total_bayar']?></td>
                        <td><?php echo $row['username']?></td>
                        <td><?php echo $row['keterangan']?></td>
                        <td>
                          <a href="Controller/pembelianController.php?aksi=hapus&faktur=<?php echo $row['faktur']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                          <a href="?p=pembelian&page=update&faktur=<?php echo $row['faktur']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
                          <a href="?p=pembelian&page=detail&faktur=<?php echo $row['faktur']?>" class="btn btn-success">Detail</a>
                        </td>
                      </tr>
                      <?php $i++;}?>
                    </tbody>
            </table>
            <?php
                    break;
                    case 'entri':
                    $datasup = mysqli_query($koneksi,'select * from supplier');
                    ?>
                    <h2>Input Data Pembelian</h2>
                    <form class="form-group mt-5" action="Controller/pembelianController.php?aksi=tambah" method="post" id="form_detail_pembelian">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Supllier
                        </div>
                        <div class="col-md-2">
                          <select class="form-control" name="namaSupplier">
                            <?php while($row = mysqli_fetch_array($datasup)){?>
                              <option value="<?=$row['id_supplier']?>"><?=$row['nama_supplier']?></option>
                            <?php } ?>
                          </select>
                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          No Faktur
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="text" name="txtNoFaktur" class="form-control txtNoFaktur" id="txtNoFaktur" data-faktur="" readonly>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          <button type="button" name="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-primary">Tambah Barang</button>
                        </div>
                        <div class="col-md-5">

                        </div>
                      </div>
                      <div class="row mt-2 ml-1 mr-1">
                        <table class="table table-bordered text-center" id="table_detail">
                          <thead>
                            <tr class="bg-primary">
                              <th>No</th>
                              <th>Nama Barang</th>
                              <th>Jumlah Barang</th>
                              <th>Harga Beli</th>
                              <th>Sub Total</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                                $today = date('ymd');
                                $cari_faktur = mysqli_query($koneksi,"select max(faktur) as last from pembelian where faktur like '$today%'");
                                $data = mysqli_fetch_array($cari_faktur);
                                if($data['last']){
                                  $nomor = explode("-",$data['last'],2);
                                  $faktur = $today.'-'.str_pad(($nomor[1]+1),3,'0',STR_PAD_LEFT);
                                }else{
                                  $faktur = $today.'-'.'001';
                                }
                                $data = mysqli_query($koneksi,"select detail_pembelian.id as 'id',barang.nama_barang as 'nama_barang',detail_pembelian.jml_barang as 'jml_barang',
                                detail_pembelian.harga_beli as'harga_beli',detail_pembelian.sub_total as 'sub_total'
                                from detail_pembelian
                                Inner Join barang
                                ON barang.id_barang = detail_pembelian.id_barang
                                where detail_pembelian.faktur='$faktur';
                                ");
                                $i =1;
                                while ($row=mysqli_fetch_array($data)) {
                             ?>
                             <tr>
                               <td><?=$i?></td>
                               <td><?=$row['nama_barang']?></td>
                               <td><?=$row['jml_barang']?></td>
                               <td><?=number_format($row['harga_beli'],'0',',','.')?></td>
                               <td><?=number_format($row['sub_total'],'0',',','.')?></td>
                               <td><a href="Controller/pembelianController.php?aksi=hapus_detail&id=<?php echo $row['id']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a></td>
                             </tr>
                           <?php  $i++;}?>
                          </tbody>
                        </table>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          Total
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="text" name="txtTotal" id="txtTotal" class="form-control" readonly>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          Keterangan
                        </div>
                        <div class="col-md-2 pull-right">
                          <textarea rows="4" cols="80" class="form-control" name="txtKeterangan"></textarea>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-10">
                          &nbsp;
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                          <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                        </div>
                      </div>
                    </form>
                    <?php
                      break;
                      case 'update':
                      $datasup = mysqli_query($koneksi,'select * from supplier');
                      $ambil = mysqli_query($koneksi,"select * from pembelian where faktur='$_GET[faktur]'");
                      $data = mysqli_fetch_array($ambil);
                    ?>
                    <h2>Update Data Pembelian</h2>
                    <form class="form-group mt-5" action="Controller/pembelianController.php?aksi=ubah&faktur=<?php echo $data['faktur']?>" method="post" id="form_detail_pembelian">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Supplier
                        </div>
                        <div class="col-md-2">
                          <select class="form-control" name="namaSupplier">
                            <?php while($row = mysqli_fetch_array($datasup)){?>
                              <option value="<?=$row['id_supplier']?>"><?=$row['nama_supplier']?></option>
                            <?php } ?>
                          </select>
                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          No Faktur
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="text" name="txtNoFaktur" class="form-control txtNoFaktur" value="<?=$data['faktur'] ?>" data-faktur="<?=$data['faktur'] ?>"  id="txtNoFaktur" readonly>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          <button type="button" name="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-primary">Tambah Barang</button>
                        </div>
                        <div class="col-md-5">

                        </div>
                      </div>
                      <div class="row mt-2 ml-1 mr-1">
                        <table class="table table-bordered text-center" id="table_detail">
                          <thead>
                            <tr class="bg-primary">
                              <th>No</th>
                              <th>Nama Barang</th>
                              <th>Jumlah Barang</th>
                              <th>Harga Beli</th>
                              <th>Sub Total</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                                $faktur = $_GET['faktur'];
                                $data1 = mysqli_query($koneksi,"select detail_pembelian.id as 'id',barang.nama_barang as 'nama_barang',detail_pembelian.jml_barang as 'jml_barang',
                                detail_pembelian.harga_beli as'harga_beli',detail_pembelian.sub_total as 'sub_total'
                                from detail_pembelian
                                Inner Join barang
                                ON barang.id_barang = detail_pembelian.id_barang
                                where detail_pembelian.faktur='$faktur';
                                ");
                                $i =1;
                                while ($row=mysqli_fetch_array($data1)) {
                             ?>
                             <tr>
                               <td><?=$i?></td>
                               <td><?=$row['nama_barang']?></td>
                               <td><?=$row['jml_barang']?></td>
                               <td><?=number_format($row['harga_beli'],'0',',','.')?></td>
                               <td><?=number_format($row['sub_total'],'0',',','.')?></td>
                               <td><a href="Controller/pembelianController.php?aksi=hapus_detail&id=<?php echo $row['id']?>&faktur=<?=$faktur?>&page=<?=$_GET['page'] ?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a></td>
                             </tr>
                           <?php  $i++;}?>
                          </tbody>
                        </table>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          Total
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="text" name="txtTotal" id="txtTotal" class="form-control" readonly>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          Keterangan
                        </div>
                        <div class="col-md-2 pull-right">
                          <textarea rows="4" cols="80" class="form-control" name="txtKeterangan"><?=$data['keterangan'] ?></textarea>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-10">
                          &nbsp;
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                          <a href="index.php?p=pembelian" class="btn btn-danger">Kembali</a>
                        </div>
                      </div>
                    </form>
                    <?php
                      break;
                      case 'detail':
                      $datasup = mysqli_query($koneksi,'select * from supplier');
                      $ambil = mysqli_query($koneksi,"select * from pembelian where faktur='$_GET[faktur]'");
                      $data = mysqli_fetch_array($ambil);
                    ?>
                    <h2>Data Detail Pembelian</h2>
                    <form class="form-group mt-5" action="Controller/pembelianController.php?aksi=ubah&faktur=<?php echo $data['faktur']?>" method="post" id="form_detail_pembelian">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Pelanggan
                        </div>
                        <div class="col-md-2">
                          <select class="form-control" name="namaSupplier">
                            <?php while($row = mysqli_fetch_array($datasup)){?>
                              <option value="<?=$row['id_supplier']?>"><?=$row['nama_supplier']?></option>
                            <?php } ?>
                          </select>
                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          No Faktur
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="text" name="txtNoFaktur" class="form-control txtNoFaktur" value="<?=$data['faktur'] ?>" data-faktur="<?=$data['faktur'] ?>"  id="txtNoFaktur" readonly>
                        </div>
                      </div>
                      <div class="row mt-2 ml-1 mr-1">
                        <table class="table table-bordered text-center" id="table_detail">
                          <thead>
                            <tr class="bg-primary">
                              <th>No</th>
                              <th>Nama Barang</th>
                              <th>Jumlah Barang</th>
                              <th>Harga Beli</th>
                              <th>Sub Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                                $faktur = $_GET['faktur'];
                                $data1 = mysqli_query($koneksi,"select detail_pembelian.id as 'id',barang.nama_barang as 'nama_barang',detail_pembelian.jml_barang as 'jml_barang',
                                detail_pembelian.harga_beli as'harga_beli',detail_pembelian.sub_total as 'sub_total'
                                from detail_pembelian
                                Inner Join barang
                                ON barang.id_barang = detail_pembelian.id_barang
                                where detail_pembelian.faktur='$faktur';
                                ");
                                $i =1;
                                while ($row=mysqli_fetch_array($data1)) {
                             ?>
                             <tr>
                               <td><?=$i?></td>
                               <td><?=$row['nama_barang']?></td>
                               <td><?=$row['jml_barang']?></td>
                               <td><?=number_format($row['harga_beli'],'0',',','.')?></td>
                               <td><?=number_format($row['sub_total'],'0',',','.')?></td>
                             </tr>
                           <?php  $i++;}?>
                          </tbody>
                        </table>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          Total
                        </div>
                        <div class="col-md-2 pull-right">
                          <input type="text" name="txtTotal" id="txtTotal" class="form-control" readonly>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-2">

                        </div>
                        <div class="col-md-5">

                        </div>
                        <div class="col-md-1">
                          Keterangan
                        </div>
                        <div class="col-md-2 pull-right">
                          <textarea rows="4" cols="80" class="form-control" name="txtKeterangan" readonly><?=$data['keterangan'] ?></textarea>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-10">
                          &nbsp;
                        </div>
                        <div class="col-md-2 pull-right">
                          <a href="index.php?p=pembelian" class="btn btn-primary">Kembali</a>
                        </div>
                      </div>
                    </form>
                    <?php
                      break;
                      }
                    ?>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div class="modal fade" id="modal-primary" style="display: none;">
  <form action="Controller/pembelianController.php?aksi=tambahdetail&page=<?=$_GET['page']?>" method="post" id="insert_form">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Tambah Barang</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <input type="text" class="form-control" name="noFakturDetail" id="noFakturDetail" style="display:none">
          </div>
          <div class="form-group">
            <label for="">Nama Barang</label>
            <select class="form-control" name="id_barang">
              <option>Pilih Barang</option>
              <?php
                $data = mysqli_query($koneksi,"select * from barang");
                while($row=mysqli_fetch_array($data)){
              ?>
                  <option value="<?=$row['id_barang'] ?>"><?=$row['nama_barang'] ?></option>
              <?php
                  }
              ?>
            </select>
          </div>
          <div class="form-group mt-2">
            <label for="">Jumlah Barang</label>
            <input type="number" class="form-control" name="jumlahbarang" id="jumlahbarang">
          </div>
          <div class="form-group mt-2">
            <label for="">Harga Beli</label>
            <input type="text" class="form-control" name="hargabeli" value="" id="hargabeli">
          </div>
          <div class="form-group mt-2">
            <label for="">Sub Total</label>
            <input type="number" class="form-control" name="subtotal" id="subtotal">
          </div>
        </div>
        <div class="modal-footer">
          <button type="reset" class="btn btn-default pull-left">Cancel</button>
          <button type="submit" name="btnSubmit" class="btn btn-primary" id="save">Save</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </form>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    const faktur = $('#txtNoFaktur').data('faktur');
    if(faktur==""){
      $.ajax({
        url:'getNoFaktur.php?j=pembelian',
        success:function(data){
          $('#txtNoFaktur').val(data);
          $('#noFakturDetail').val(data);
  		      panggilTotal(data);
        }
      });
    }else{
      panggilTotal(faktur);
      $('#noFakturDetail').val(faktur);
    }
    $('#hargabeli').on('change',function(){
      var total = $('#hargabeli').val() * $('#jumlahbarang').val();
      $('#subtotal').val(total);
    });

    function panggilTotal(nomorfaktur){
      $.ajax({
        url:'getTotal.php?j=pembelian',
        data:"nofaktur="+nomorfaktur,
        success:function(data){
          $('#txtTotal').val(data);
        }
      });
    }
  });
</script>
