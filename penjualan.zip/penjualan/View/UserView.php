<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      List User
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="box box-primary">
      <div class="box-body">
              <?php
              $page=isset($_GET['page'])?$_GET['page']:'list';
              switch ($page) {
              case 'list':
          ?>
          <p><a href="?p=user&page=entri" class="btn btn-primary"><i class="fasfa-save mr-2"></i>Tambah User</a></p>
          <table class="table table-bordered text-center mt-3" id="example1">
              <thead>
                <tr class="bg-primary">
                    <th>No</th>
                    <th>Username</th>
                    <th>Level</th>
                    <th>Email</th>
                    <th>NoTelp</th>
                    <th>Photo</th>
                    <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $data = mysqli_query($koneksi,"select * from user");
                    $i =1;
                    while ($row=mysqli_fetch_array($data)) {
                 ?>
                 <tr>
                        <td><?php echo $i?></td>
                        <td><?php echo $row['username']?></td>
                        <td><?php echo $row['level']?></td>
                        <td><?=$row['email']?></td>
                        <td><?=$row['notelp']?></td>
                        <td><img src="bower_components/img/<?=$row['foto']?>" width="70px" height="70px"></td>
                        <td>
                          <a href="Controller/UserController.php?aksi=hapus&username=<?php echo $row['username']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                          <a href="?p=user&page=update&username=<?php echo $row['username']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
                          <a href="" class="btn btn-success">Detail</a>
                        </td>
                      </tr>
                      <?php $i++;}?>
              </tbody>
          </table>
          <?php
                  break;
                  case 'entri':
                  ?>
                  <h2>Input Data User</h2>
                  <form class="form-group mt-5" method="post" action="Controller/UserController.php?aksi=tambah" enctype="multipart/form-data">
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Username
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtUserName" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Password
                      </div>
                      <div class="col-md-5">
                        <input type="password" name="txtPassword" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Level
                      </div>
                      <div class="col-md-5">
                        <select class="form-control" name="level">
                          <option value="Administrator">Administrator</option>
                          <option value="Anggota">Anggota</option>
                        </select>
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Email
                      </div>
                      <div class="col-md-5">
                        <input type="email" name="txtEmail" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        No Telpon
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtnotelp" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Foto
                      </div>
                      <div class="col-md-5">
                        <input type="file" name="fileAp" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        &nbsp;
                      </div>
                      <div class="col-md-5">
                        <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                        <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                      </div>
                    </div>

                  </form>
                <?php
                  break;
                  case 'update':
                  $ambil = mysqli_query($koneksi,"select * from user where username='$_GET[username]'");
                  $data = mysqli_fetch_array($ambil);
                  ?>
                  <h2>Update Data Supplier</h2>
                  <form class="form-group mt-5" method="post" action="Controller/UserController.php?aksi=ubah&username=<?php echo $data['username']?>" enctype="multipart/form-data">
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Password
                      </div>
                      <div class="col-md-5">
                        <input type="password" name="txtPassword" class="form-control" value="<?=$data['password'] ?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Level
                      </div>
                      <div class="col-md-5">
                        <select class="form-control" name="level">
                          <option value="Administrator">Administrator</option>
                          <option value="Anggota">Anggota</option>
                        </select>
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Email
                      </div>
                      <div class="col-md-5">
                        <input type="email" name="txtEmail" class="form-control" value="<?=$data['email'] ?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        No Telpon
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtnotelp" class="form-control" value="<?=$data['notelp'] ?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Foto
                      </div>
                      <div class="col-md-5">
                        <input type="file" name="fileAp" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        &nbsp;
                      </div>
                      <div class="col-md-5">
                        <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                        <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                      </div>
                    </div>
                  </form>
                  <?php
                    break;
                    }
                  ?>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
