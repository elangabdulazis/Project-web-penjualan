<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      List Supplier
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="box box-primary">
      <div class="box-body">
              <?php
              $page=isset($_GET['page'])?$_GET['page']:'list';
              switch ($page) {
              case 'list':
          ?>
          <p><a href="?p=supplier&page=entri" class="btn btn-primary"><i class="fasfa-save mr-2"></i>Tambah Supplier</a></p>
          <table class="table table-bordered text-center mt-3" id="example1">
              <thead>
                <tr class="bg-primary">
                    <th>No</th>
                    <th>Nama Supplier</th>
                    <th>Telp</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Kota</th>
                    <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $data = mysqli_query($koneksi,"select * from supplier");
                    $i =1;
                    while ($row=mysqli_fetch_array($data)) {
                 ?>
                 <tr>
                      <td><?php echo $i?></td>
                      <td><?php echo $row['nama_supplier']?></td>
                      <td><?php echo $row['telp']?></td>
                      <td><?php echo $row['email']?></td>
                      <td><?php echo $row['alamat']?></td>
                      <td><?php echo $row['kota']?></td>
                      <td>
                        <a href="Controller/supplierController.php?aksi=hapus&id_supplier=<?php echo $row['id_supplier']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                        <a href="?p=supplier&page=update&id_supplier=<?php echo $row['id_supplier']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
                        <a href="" class="btn btn-success">Detail</a>
                      </td>
                  </tr>
                <?php $i++;}?>
              </tbody>
          </table>
          <?php
                  break;
                  case 'entri':
                  ?>
                  <h2>Input Data Supplier</h2>
                  <form class="form-group mt-5" method="post" action="Controller/supplierController.php?aksi=tambah">
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Nama Supplier
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtNamaSup" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Telp
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtTelp" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Email
                      </div>
                      <div class="col-md-5">
                        <input type="email" name="txtEmail" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Alamat
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtAlmt" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Kelurahan
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtKel" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Kecamatan
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtKec" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Kota
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtKota" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Provinsi
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtProv" class="form-control">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        &nbsp;
                      </div>
                      <div class="col-md-5">
                        <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                        <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                      </div>
                    </div>
                  </form>
                <?php
                  break;
                  case 'update':
                $ambil = mysqli_query($koneksi,"select * from supplier where id_supplier='$_GET[id_supplier]'");
                $data2 = mysqli_fetch_array($ambil);
                  ?>
                  <h2>Update Data Supplier</h2>
                  <form class="form-group mt-5" method="post" action="Controller/supplierController.php?aksi=ubah&id_supplier=<?php echo $data2['id_supplier']?>">
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Nama Supplier
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtNamaSup" class="form-control" value="<?php  echo $data2['nama_supplier']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Telp
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtTelp" class="form-control" value="<?php echo $data2['telp']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Email
                      </div>
                      <div class="col-md-5">
                        <input type="email" name="txtEmail" class="form-control" value="<?php echo $data2['email']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Alamat
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtAlmt" class="form-control" value="<?php echo $data2['alamat']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Kelurahan
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtKel" class="form-control" value="<?php echo $data2['kelurahan']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Kecamatan
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtKec" class="form-control" value="<?php echo $data2['kecamatan']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Kota
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtKota" class="form-control" value="<?php echo $data2['kota']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        Provinsi
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="txtProv" class="form-control" value="<?php echo $data2['provinsi']?>">
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-2">
                        &nbsp;
                      </div>
                      <div class="col-md-5">
                        <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                        <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                      </div>
                    </div>
                  </form>
                  <?php
                    break;
                    }
                  ?>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
