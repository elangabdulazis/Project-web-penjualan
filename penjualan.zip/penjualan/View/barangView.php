<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      List Barang
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="box box-primary">
      <div class="box-body ">
            <?php
                $page=isset($_GET['page'])?$_GET['page']:'list';
                switch ($page) {
                case 'list':
            ?>
            <p><a href="?p=barang&page=entri" class="btn btn-primary"><i class="fasfa-save mr-2"></i>Tambah Barang</a> <a href="./laporanBarang.php" class="btn btn-success"><i class="fasfa-save mr-2"></i>Laporan</a></p>

            <table class="table table-bordered text-center mt-3" id="example1">
                <thead>
                  <tr class="bg-primary">
                      <th>No</th>
                      <th>Nama Barang</th>
                      <th>Jenis</th>
                      <th>Satuan</th>
                      <th>Harga Beli</th>
                      <th>Harga Jual</th>
                      <th>Stok</th>
                      <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                    $data = mysqli_query($koneksi,
                        "select id_barang,nama_barang,jenis_barang.nama_jenis,satuan,harga_beli,harga_jual,stok
                        from barang INNER JOIN jenis_barang
                        ON barang.id_jenis= jenis_barang.id_jenis
                        ");
                    $i =1;
                    while ($row=mysqli_fetch_array($data)) {
                 ?>
                 <tr>
                        <td><?= $i?></td>
                        <td><?= $row['nama_barang']?></td>
                        <td><?= $row['nama_jenis']?></td>
                        <td><?= $row['satuan']?></td>
                        <td><?= number_format($row['harga_beli'],'0',',','.')?></td>
                        <td><?= number_format($row['harga_jual'],'0',',','.')?></td>
                        <td><?= $row['stok']?></td>
                        <td>
                          <a href="Controller/barangController.php?aksi=hapus&id_barang=<?php echo $row['id_barang']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                          <a href="?p=barang&page=update&id_barang=<?php echo $row['id_barang']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
                          <a href="" class="btn btn-success">Detail</a>
                        </td>
                      </tr>
                      <?php $i++;}?>
                    </tbody>
            </table>
            <?php
                    break;
                    case 'entri':
                    $data = mysqli_query($koneksi,"select * from jenis_barang");
                    ?>
                    <h2>Input Data Barang</h2>
                    <form class="form-group mt-5" method="post" action="Controller/barangController.php?aksi=tambah">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Nama Barang
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtNamaBar" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Jenis Barang
                        </div>
                        <div class="col-md-5">
                          <select name="cmbJenis" class="form-control">
                            <?php
                                while($row=mysqli_fetch_array($data)){
                            ?>
                                <option value="<?=$row['id_jenis'] ?>"><?=$row['nama_jenis'] ?></option>
                            <?php
                                }
                            ?>
                          </select>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Satuan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtSatuan" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Harga Beli
                        </div>
                        <div class="col-md-5">
                          <input type="number" name="txtHargaBeli" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Harga Jual
                        </div>
                        <div class="col-md-5">
                          <input type="number" name="txtHargaJual" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Stok
                        </div>
                        <div class="col-md-5">
                          <input type="number" name="txtStok" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          &nbsp;
                        </div>
                        <div class="col-md-5">
                          <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                          <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                        </div>
                      </div>
                    </form>
                  <?php
                    break;
                    case 'update':
                    $ambil = mysqli_query($koneksi,"select * from barang where id_barang='$_GET[id_barang]'");
                    $data = mysqli_fetch_array($ambil);
                    ?>
                    <h2>Update Data Barang</h2>
                    <form class="form-group mt-5" method="post" action="Controller/barangController.php?aksi=ubah&id_barang=<?php echo $data['id_barang']?>">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Nama Barang
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtNamaBar" class="form-control" value="<?=$data['nama_barang']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Jenis Barang
                        </div>
                        <div class="col-md-5">
                          <select name="cmbJenis" class="form-control">
                            <?php
                                $datajenis = mysqli_query($koneksi,'select * from jenis_barang');
                                while($row=mysqli_fetch_array($datajenis)){
                            ?>
                            <option value='<?php  echo "$row[id_jenis]" ?>' <?php  if($row['id_jenis']== $data['id_jenis']) echo "selected='selected'"?> ><?php  echo "$row[nama_jenis]"?></option>
                            <?php
                              }
                            ?>

                          </select>
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Satuan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtSatuan" class="form-control" value="<?=$data['satuan']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Harga Beli
                        </div>
                        <div class="col-md-5">
                          <input type="number" name="txtHargaBeli" class="form-control" value="<?=$data['harga_beli']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Harga Jual
                        </div>
                        <div class="col-md-5">
                          <input type="number" name="txtHargaJual" class="form-control" value="<?=$data['harga_jual']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Stok
                        </div>
                        <div class="col-md-5">
                          <input type="number" name="txtStok" class="form-control" value="<?=$data['stok']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          &nbsp;
                        </div>
                        <div class="col-md-5">
                          <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                          <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                        </div>
                      </div>
                    </form>
                    <?php
                      break;
                      }
                    ?>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
