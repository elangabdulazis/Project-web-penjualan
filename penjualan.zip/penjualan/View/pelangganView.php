<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      List Pelanggan
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="box box-primary">
      <div class="box-body ">
        <?php
                include('koneksi.php');
              ?>
            <?php
                $page=isset($_GET['page'])?$_GET['page']:'list';
                switch ($page) {
                case 'list':
            ?>
            <p><a href="?p=pelanggan&page=entri" class="btn btn-primary"><i class="fasfa-save mr-2"></i>Tambah Pelanggan</a></p>
            <table class="table table-bordered text-center mt-3" id="example1">
                <thead>
                  <tr class="bg-primary">
                      <th>No</th>
                      <th>Nama Pelanggan</th>
                      <th>Telp</th>
                      <th>Email</th>
                      <th>Alamat</th>
                      <th>Kota</th>
                      <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                    $data = mysqli_query($koneksi,"select * from pelanggan");
                    $i =1;
                    while ($row=mysqli_fetch_array($data)) {
                 ?>
                 <tr>
                        <td><?php echo $i?></td>
                        <td><?php echo $row['nama_pelanggan']?></td>
                        <td><?php echo $row['telp']?></td>
                        <td><?php echo $row['email']?></td>
                        <td><?php echo $row['alamat']?></td>
                        <td><?php echo $row['kota']?></td>
                        <td>
                          <a href="Controller/pelangganController.php?aksi=hapus&id_pelanggan=<?php echo $row['id_pelanggan']?>" class="btn btn-danger pr-2 pl-2" onclick="return confirm('Anda yakin ingin menghapus')"><i class="fas fa-trash mr-2"></i>Hapus</a>
                          <a href="?p=pelanggan&page=update&id_pelanggan=<?php echo $row['id_pelanggan']?>" class="btn btn-primary ml-2 pr-2 pl-2"><i class="far fa-edit mr-2"></i>Edit</a>
                          <a href="" class="btn btn-success">Detail</a>
                        </td>
                      </tr>
                      <?php $i++;}?>
                    </tbody>
            </table>
            <?php
                    break;
                    case 'entri':
                    ?>
                    <h2>Input Data Pelanggan</h2>
                    <form class="form-group mt-5" method="post" action="Controller/pelangganController.php?aksi=tambah">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Nama Pelanggan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtNamaPel" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Telp
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtTelp" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Email
                        </div>
                        <div class="col-md-5">
                          <input type="email" name="txtEmail" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Alamat
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtAlmt" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Kelurahan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtKel" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Kecamatan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtKec" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Kota
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtKota" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Provinsi
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtProv" class="form-control">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          &nbsp;
                        </div>
                        <div class="col-md-5">
                          <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                          <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                        </div>
                      </div>
                    </form>
                  <?php
                    break;
                    case 'update':
                    $ambil = mysqli_query($koneksi,"select * from pelanggan where id_pelanggan='$_GET[id_pelanggan]'");
                    $data2 = mysqli_fetch_array($ambil);
                    ?>
                    <h2>Update Data Pelanggan</h2>
                    <form class="form-group mt-5" method="post" action="Controller/pelangganController.php?aksi=ubah&id_pelanggan=<?php echo $data2['id_pelanggan']?>">
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Nama Pelanggan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtNamaPel" class="form-control" value="<?php  echo $data2['nama_pelanggan']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Telp
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtTelp" class="form-control" value="<?php echo $data2['telp']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Email
                        </div>
                        <div class="col-md-5">
                          <input type="email" name="txtEmail" class="form-control" value="<?php echo $data2['email']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Alamat
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtAlmt" class="form-control" value="<?php echo $data2['alamat']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Kelurahan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtKel" class="form-control" value="<?php echo $data2['kelurahan']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Kecamatan
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtKec" class="form-control" value="<?php echo $data2['kecamatan']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Kota
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtKota" class="form-control" value="<?php echo $data2['kota']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          Provinsi
                        </div>
                        <div class="col-md-5">
                          <input type="text" name="txtProv" class="form-control" value="<?php echo $data2['provinsi']?>">
                        </div>
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-2">
                          &nbsp;
                        </div>
                        <div class="col-md-5">
                          <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary">
                          <input type="reset" name="btnReset" value="Reset" class="btn btn-danger">
                        </div>
                      </div>
                    </form>
                    <?php
                      break;
                      }
                    ?>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
