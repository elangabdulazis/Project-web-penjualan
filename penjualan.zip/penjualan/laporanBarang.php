<?php
  include('view/koneksi.php');
  include('FPDF/fpdf.php');
  $pdf = new FPDF();
  $pdf->addPage();
  $pdf->setFont('Arial','B',12);
  $pdf->Cell(180,30,'LAPORAN BARANG',0,1,'C');
  $pdf->Line(15, 45, 210-14, 45);
  $pdf->Cell(180,-20,'PT DIKI',0,1,'C');
  $pdf->Cell(180,30,'Jln. Pauh No.12',0,1,'C');
  $pdf->setFont('Arial','i',8);
  $pdf->Cell(180,-20,'No Telp. 0892312323445, FAX:1245245',0,1,'C');
  $data = mysql_query("select * from penjualan");
  $yi = 100;
  $ya = 48;
  $pdf->setFont('Arial','',9);
  $pdf->setFillColor(222,222,222);
  $pdf->setXY(20,$ya);
  $pdf->CELL(6,6,'NO',1,0,'C',1);
  $pdf->CELL(25,6,'Nama Barang',1,0,'C',1);
  $pdf->CELL(25,6,'Jenis',1,0,'C',1);
  $pdf->CELL(25,6,'Satuan',1,0,'C',1);
  $pdf->CELL(30,6,'Harga Beli',1,0,'C',1);
  $pdf->CELL(30,6,'Harga Jual',1,0,'C',1);
  $pdf->CELL(30,6,'Stok',1,0,'C',1);
  $pdf->setXY(20,$ya+5);
  $i=1;
  $query = mysqli_query($koneksi, "select * from barang,jenis_barang
                        where barang.id_jenis = jenis_barang.id_jenis");
  while ($row = mysqli_fetch_array($query)){
    $pdf->Cell(6,6,$i,1,0,'C',1);
    $pdf->Cell(25,6,$row['nama_barang'],1,0,'C',1);
    $pdf->Cell(25,6,$row['nama_jenis'],1,0,'C',1);
    $pdf->Cell(25,6,$row['satuan'],1,0,'C',1);
    $pdf->Cell(30,6,number_format($row['harga_beli'],'0','.','.'),1,0,'C',1);
    $pdf->Cell(30,6,number_format($row['harga_jual'],'0','.','.'),1,0,'C',1);
    $pdf->Cell(30,6,$row['stok'],1,0,'C',1);
    $pdf->setXY(15,$ya+10);
    $i++;
  }

  $pdf->Output();
?>
