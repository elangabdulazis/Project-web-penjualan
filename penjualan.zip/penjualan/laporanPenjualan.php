<?php
  include('view/koneksi.php');
  include('FPDF/fpdf.php');
  $pdf = new FPDF();
  $pdf->addPage();
  $pdf->setFont('Arial','B',12);
  $pdf->Cell(180,30,'LAPORAN PENJUALAN',0,1,'C');
  $pdf->Line(15, 45, 210-14, 45);
  $pdf->Cell(180,-20,'PT DIKI',0,1,'C');
  $pdf->Cell(180,30,'Jln. Pauh No.12',0,1,'C');
  $pdf->setFont('Arial','i',8);
  $pdf->Cell(180,-20,'No Telp. 0892312323445, FAX:1245245',0,1,'C');
  $data = mysql_query("select * from penjualan");
  $yi = 100;
  $ya = 48;
  $pdf->setFont('Arial','',9);
  $pdf->setFillColor(222,222,222);
  $pdf->setXY(15,$ya);
  $pdf->CELL(6,6,'NO',1,0,'C',1);
  $pdf->CELL(25,6,'Faktur',1,0,'C',1);
  $pdf->CELL(35,6,'Tanggal',1,0,'C',1);
  $pdf->CELL(40,6,'Nama Pelanggan',1,0,'C',1);
  $pdf->CELL(40,6,'Total Bayar',1,0,'C',1);
  $pdf->CELL(35,6,'Keterangan',1,1,'C',1);
  $pdf->setXY(15,$ya+5);
  $i=1;
  $query = mysqli_query($koneksi, "select * from penjualan,pelanggan
                        where penjualan.id_pelanggan = pelanggan.id_pelanggan");
  while ($row = mysqli_fetch_array($query)){
    $pdf->Cell(6,6,$i,1,0,'C',1);
    $pdf->Cell(25,6,$row['faktur'],1,0,'C',1);
    $pdf->Cell(35,6,$row['tgl_penjualan'],1,0,'C',1);
    $pdf->Cell(40,6,$row['nama_pelanggan'],1,0,'C',1);
    $pdf->Cell(40,6,number_format($row['total_bayar'],'0','.','.'),1,0,'C',1);
    $pdf->Cell(35,6,$row['keterangan'],1,0,'C',1);
    $pdf->setXY(15,$ya+10);
    $i++;
  }
  
  $pdf->Output();
?>
